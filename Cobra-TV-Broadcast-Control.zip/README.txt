Cobra-TV Broadcast Control
===========================

الملف الرئيسي:
  index.html

المميزات:
- تسجيل دخول Firebase Authentication بالبريد وكلمة المرور.
- اتصال حي بـ Firestore.
- غرفة بث: تشغيل/إيقاف/التالي وتقديم/تأخير دقيقة أو 5 دقائق.
- جدول بث schedules.
- إدارة تعليقات اللايف من streams/live_stream_1/comments.
- إعدادات اللوجو والبنرات على نفس وثيقة streams/live_stream_1.
- تصميم عربي RTL متجاوب.

مهم قبل التشغيل:
1) فعّل Email/Password في Firebase Authentication.
2) أنشئ مستخدم Admin من Firebase Authentication.
3) ضع قواعد Firestore المناسبة للإنتاج. ملف firestore.rules المرفق نقطة بداية فقط؛ لا تتركه مفتوحًا لأي مستخدم موثق إذا كان لديك مستخدمون عاديون.
4) افتح الموقع عبر HTTPS أو خادم محلي، وليس file:// فقط.

ملاحظة:
هذا الموقع يستخدم حقولًا متوافقة مع UltraLiveStreamScreen الذي شاركته:
playbackState, movieTitle, movieCategory, currentStreamUrl, logoUrl,
portTop, portRight, portWidth, landTop, landRight, landWidth,
topBannerUrl, topBannerWidth, topBannerTopPx, nextMovieBannerUrl
ومسار التعليقات streams/live_stream_1/comments.
